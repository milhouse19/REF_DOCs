#include "nupp/spi.hpp"
#include "nupp/timer.hpp"
#include <../../pic32-libs/peripheral/spi/source/_spi_map_tbl.h>

using namespace nu;

uint32_t ALWAYSINLINE SPI::get_bitrate(SpiChannel chn) {
	uint32_t clk_div = (_SpiMapTbl[chn]->brg+1)*2;
	return (uint32_t) param::pbus_hz()/clk_div; //bitrate
}

void ALWAYSINLINE SPI::wait_busy() {
	uint32_t bit_time_ns = 1000000000/this->get_bitrate(chn);
	while (SpiChnIsBusy(chn)) {
		Nop();
	}
	timer::delay_ns(bit_time_ns);
}

void SPI::tx(const void *src, size_t n) {
	uint32_t ui;
	if (!(opt & TX_DISABLE_AUTO_CS)) cs.low();

    if (opt & TX_WAIT_START)
        wait_busy();

    if (_SpiMapTbl[chn]->con.MODE32) {
        const uint32_t *elems = (const uint32_t *)src;
        SpiChnWriteC(chn, elems[0]);
        for (ui = 1; ui < n; ++ui)
            SpiChnPutC(chn, elems[ui]);
    } else if (_SpiMapTbl[chn]->con.MODE16) {
        const uint16_t *elems = (const uint16_t *)src;
        SpiChnWriteC(chn, elems[0]);
        for (ui = 1; ui < n; ++ui)
            SpiChnPutC(chn, elems[ui]);
    } else {    /* 8-bit mode */
        const uint8_t *elems = (const uint8_t *)src;
        SpiChnWriteC(chn, elems[0]);
        for (ui = 1; ui < n; ++ui)
            SpiChnPutC(chn, elems[ui]);
    }

    if (opt & TX_WAIT_END)
        wait_busy();
	if (!(opt & TX_DISABLE_AUTO_CS)) cs.high();
}

void SPI::rx(void *dst, size_t n) {
	uint32_t ui;

	while (SpiChnRxBuffCount(chn)) {
		SpiChnReadC(chn);
	}

	if (_SpiMapTbl[chn]->con.MODE32) {
		uint32_t *elems = (uint32_t *)dst;
		SpiChnPutC(chn, 0);
		SpiChnGetRov(chn, 1);
		for (ui = 0; ui < n; ++ui)
			elems[ui] = SpiChnGetC(chn);
	} else if (_SpiMapTbl[chn]->con.MODE16) {
		uint16_t *elems = (uint16_t *)dst;
		SpiChnPutC(chn, 0);
		SpiChnGetRov(chn, 1);
		for (ui = 0; ui < n; ++ui)
			elems[ui] = (uint16_t)SpiChnGetC(chn);
	} else {    /* 8-bit mode */
		uint8_t *elems = (uint8_t *)dst;
		SpiChnPutC(chn, 0);
		SpiChnGetRov(chn, 1);
		for (ui = 0; ui < n; ++ui)
			elems[ui] = (uint8_t)SpiChnGetC(chn);
	}
}
