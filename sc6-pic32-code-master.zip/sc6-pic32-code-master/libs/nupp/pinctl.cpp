//
//  pinctl.cpp
//  nusolar_lib
//
//  Created by Al Chandel on 5/5/13.
//  Copyright (c) 2013 Alex Chandel. All rights reserved.
//

#include "nupp/pinctl.hpp"

using namespace nu;

uint16_t AnalogIn::enabled_ADCs = 0;
