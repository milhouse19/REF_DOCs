#ifndef NU_PLATFORM_H
#define NU_PLATFORM_H 1

#define NU_PLATFORM_GENERIC 0
#define NU_PLATFORM_PIC32MX 1
#define NU_PLATFORM_UNKNOWN 2

#include "nu/platform/platform.h"

#endif

