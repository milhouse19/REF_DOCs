#ifndef NU_HAIS50P_H
#define NU_HAIS50P_H 1

#include "nu/compiler.h"

static ALWAYSINLINE float
voltageToCurrent(float voltage);

#endif
