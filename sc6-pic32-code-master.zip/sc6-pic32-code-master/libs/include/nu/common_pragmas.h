#ifndef NU_COMMON_PRAGMAS_H
#define NU_COMMON_PRAGMAS_H 1

#include "nu/platform/common_pragmas.h"

#endif

