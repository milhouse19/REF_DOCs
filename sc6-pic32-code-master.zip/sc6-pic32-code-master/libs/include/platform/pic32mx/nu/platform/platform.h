#ifndef NU_PLATFORM_PIC32MX_H
#define NU_PLATFORM_PIC32MX_H 1

#include "nu/platform.h"

#define NU_PLATFORM NU_PLATFORM_PIC32MX

#endif

