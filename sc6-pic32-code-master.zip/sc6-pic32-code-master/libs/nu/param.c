#include "nu/param.h"

nu_hz_t nu_hz = NU_DEFAULT_HZ;
